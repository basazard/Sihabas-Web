# Changelog

## [1.4.0]

### Updated
 
- Minor packages update

## [1.3.0]

### Updated

- Angular Material upgraded to 1.0
- Angular upgraded to 1.5
- Dependencies updated

## [1.2.0]

### Fixed

- Lot of UX/UI improvements
- Minor fixes

### New Features

- Browsers support
- Added messages section directive
- Changed app structure

## [1.1.0]

### New Features

- Implement message-section directive

## [1.0.1]

### Updated

- Update dependencies

## [1.1.0]

### New Features

- New layout
- Custom theme styles
- New dashboard sections
- Angular Material v0.10.0
- Added md-menu
- Google material icons
- NVD3 charts
- Responsive layout
- Nested views

### Fixed

- Adjusted panel-widget directive
- Stylesheets reorganized
- Widgets reworked
- Adjusted table
- Reorganized app structure
- Adjusted sidebars



